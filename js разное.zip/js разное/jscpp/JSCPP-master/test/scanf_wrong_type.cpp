#include <cstdio>

int main() {
    int i = 10;

    scanf("%s",&i);
    printf("%s ",i);

    return 0;
}