#include <cstdio>

int main() {
    char c[9];

    scanf("%s",c);
    printf("%s ",c);

    return 0;
}