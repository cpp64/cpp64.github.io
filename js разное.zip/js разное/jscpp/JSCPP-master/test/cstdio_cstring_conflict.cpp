#include <stdio.h>
#include <string.h>

int main()
{
    printf("test - ok");
    return 0;
}