#include <cstdio>

int main() {
    int a = 17;
    float b = 14.59;
    char c[50];

    scanf("%d",&a);
    printf("%d ",a);

    scanf("%f",&b);
    printf("%.2f ",b);

    scanf("%s",c);
    printf("%s ",c);

    scanf("%d",&a);
    printf("%d ",a);

    scanf("%f",&b);
    printf("%.2f ",b);
    return 0;
}