#include <iostream>

using namespace std;

int main()
{
  int n;
  cin >> n;
  if (n == 1 || n == 3 || n == 5)
    cout << "NO\n";
  else
    cout << "YES\n";
  return 0;
}