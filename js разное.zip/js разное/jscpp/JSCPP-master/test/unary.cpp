#include <iostream>
using namespace std;
int main() {
  cout << +(5) << endl;
  cout << +(-5) << endl;
  cout << -(5) << endl;
  cout << -(-5) << endl;
  cout << ~(5) << endl;
  cout << ~(-5) << endl;
  cout << !(false) << endl;
  cout << !(true) << endl;
  return 0;
}