#include<iostream>
using namespace std;
int main() {
    unsigned char x = 0;
    x--;
    cout << (int)x << endl;
    return 0;
}