#include <iostream>
using namespace std;

int main() {
	cout << 100 + 10 << endl;
	cout << 100 - 10 << endl;
	cout << 100 * 10 << endl;
	cout << 100 / 10 << endl;
	cout << 100 % 10 << endl;
	cout << (100, 10) << endl;
	cout << (100 & 10) << endl;
	cout << (100 | 10) << endl;
	cout << (100 ^ 10) << endl;
	cout << (100 << 10) << endl;
	cout << (100 >> 10) << endl;
	cout << (true && true) << endl;
	cout << (true && false) << endl;
	cout << (false && true) << endl;
	cout << (false && false) << endl;
	cout << (true || true) << endl;
	cout << (true || false) << endl;
	cout << (false || true) << endl;
	cout << (false || false) << endl;
	cout << (true + true) << endl;
	cout << (false + true) << endl;
	return 0;
}