int main() {
    int *p;
    return *p;
}