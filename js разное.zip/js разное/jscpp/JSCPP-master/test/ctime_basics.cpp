#include <iostream>
#include <ctime>

using namespace std;

int main() {
  cout << (time(0)>1459626300) << endl;
  return 0;
}
