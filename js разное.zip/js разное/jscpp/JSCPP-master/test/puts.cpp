/* puts example : hello world! */
#include <stdio.h>

int main ()
{
  char* string = "Hello world!";
  puts (string);
  return 0;
}