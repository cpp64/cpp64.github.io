#include <iostream>
using namespace std;
int main() {
  cout << 0x7fffffff << endl;
  cout << -0x80000000 << endl;
  cout << 1e-5 << endl;
  cout << 1e5 << endl;
  cout << (int)'\0' << endl;
  return 0;
}