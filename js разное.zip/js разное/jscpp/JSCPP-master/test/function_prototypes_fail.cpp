#include <iostream>

int func(int x);

int main() {
    int a = 10;
    int b = 0;    
    b = func(a);
    return b;
}