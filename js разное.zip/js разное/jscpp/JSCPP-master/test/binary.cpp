#include <iostream>
using namespace std;

int main(){
  int a = 0b1010101;
  cout << a << endl; //85
  return 0;
}