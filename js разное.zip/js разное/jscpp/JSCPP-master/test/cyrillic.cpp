#include <iostream>

using namespace std;

int main() {
    cout << "some cyrillic text: кириллический текст" <<  endl;
    return 0;
}